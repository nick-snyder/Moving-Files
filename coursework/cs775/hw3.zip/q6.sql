DROP VIEW IF EXISTS manyOrders;
CREATE VIEW manyOrders AS (SELECT DISTINCT A.customer_id FROM orders A WHERE A.customer_id IN (SELECT B.customer_id FROM orders B WHERE A.order_id < B.order_id));
SELECT customer_id, first_name FROM customers WHERE customer_id NOT IN (SELECT customer_id FROM manyOrders);
DROP VIEW IF EXISTS manyOrders;
