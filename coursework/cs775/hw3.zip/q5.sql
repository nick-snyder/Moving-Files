DROP VIEW IF EXISTS prodAnyOrders;
DROP VIEW IF EXISTS prodNoOrders;
DROP VIEW IF EXISTS prodManyOrders;
DROP VIEW IF EXISTS prodOneOrder;
DROP VIEW IF EXISTS allProdByAllCust;
CREATE VIEW prodAnyOrders AS SELECT product_id FROM orders NATURAL JOIN order_items NATURAL JOIN products;
CREATE VIEW prodNoOrders AS SELECT product_id FROM products WHERE product_id NOT IN (SELECT product_id FROM prodAnyOrders);
CREATE VIEW prodManyOrders AS (SELECT DISTINCT A.product_id FROM order_items A WHERE A.product_id IN (SELECT B.product_id FROM order_items B WHERE A.order_id < B.order_id));
CREATE VIEW prodOneOrder AS (SELECT product_id FROM products WHERE (product_id NOT IN (SELECT product_id FROM prodNoOrders)) AND (product_id NOT IN (SELECT product_id FROM prodManyOrders)));
CREATE VIEW allProdByAllCust AS SELECT customer_id, product_id, order_id, first_name FROM orders NATURAL JOIN order_items NATURAL JOIN products NATURAL JOIN customers;
SELECT order_id, product_id, customer_id, first_name FROM allProdByAllCust NATURAL JOIN prodOneOrder;
DROP VIEW IF EXISTS prodAnyOrders;
DROP VIEW IF EXISTS prodNoOrders;
DROP VIEW IF EXISTS prodManyOrders;
DROP VIEW IF EXISTS prodOneOrder;
DROP VIEW IF EXISTS allProdByAllCust;

