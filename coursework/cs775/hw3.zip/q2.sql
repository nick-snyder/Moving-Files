SELECT DISTINCT customer_id, orders.order_id FROM orders, order_items WHERE orders.order_id NOT IN (SELECT order_id FROM order_items);
