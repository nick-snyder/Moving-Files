DROP VIEW IF EXISTS cust;
CREATE VIEW cust AS (SELECT DISTINCT A.customer_id, A.order_id, A.order_date FROM orders A WHERE A.customer_id IN (SELECT B.customer_id FROM orders B WHERE A.order_id < B.order_id));
SELECT customers.first_name, cust.customer_id, cust.order_id, cust.order_date FROM cust JOIN customers ON cust.customer_id = customers.customer_id;
DROP VIEW IF EXISTS cust;

