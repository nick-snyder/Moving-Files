DROP VIEW IF EXISTS names;
CREATE VIEW names AS SELECT A.first_name AS first_name1, B.first_name AS first_name2 FROM employee A, employee B WHERE A.customer_id = B.customer_id AND A.first_name != B.first_name;
SELECT first_name1, first_name2 FROM names WHERE first_name1 < first_name2;
DROP VIEW IF EXISTS names;

