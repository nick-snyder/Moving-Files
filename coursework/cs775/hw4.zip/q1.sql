SELECT category_name FROM categories WHERE category_id IN (SELECT category_id FROM order_items NATURAL JOIN products);
