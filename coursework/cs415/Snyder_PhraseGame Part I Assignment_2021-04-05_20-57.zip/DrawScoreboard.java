import java.util.Scanner;

/**
 *
 *
 * @author Nicholas Snyder
 * @version April 5 2021
 */

public class DrawScoreboard {

    /**
     * 
     *
     * @param args main
     */

    public static void main(String[] args) {

        int totalGuesses;
        int incorrectGuesses;

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter number of guesses allowed between 1 and 11");
        totalGuesses = scanner.nextInt();

        System.out.println("Enter number of incorrect guesses");
        incorrectGuesses = scanner.nextInt();

        System.out.println(drawScoreboard(totalGuesses, incorrectGuesses));

        scanner.close();
    }

    /**
     * 
     * 
     * @param totalGuesses      int
     * @param incorrectGuesses  int
     * @return                  String
     */

    public static String drawScoreboard(int totalGuesses, int incorrectGuesses) {

        String finalResult = "+";

        for (int line1 = 0; line1 < totalGuesses; line1++) {
            
            finalResult += "-----+";

        }

        finalResult += "\n|";

        for (int line2 = 0; line2 < incorrectGuesses; line2++) {
                
            finalResult += "\\\\ //|";

        }

        if (totalGuesses > incorrectGuesses) {
            
            for (int i = incorrectGuesses; i < totalGuesses; i++) {
                
                finalResult += "     |";

            }
        }

        finalResult += "\n|";

        for (int line3 = 0; line3 < incorrectGuesses; line3++) {

            finalResult += " \\V/ |";

        }

        if (totalGuesses > incorrectGuesses) {
            
            for (int i = incorrectGuesses; i < totalGuesses; i++) {
                
                finalResult += "     |";

            }
        }

        finalResult += "\n|";

        for (int line4 = 0; line4 < incorrectGuesses; line4++) {

            finalResult += " /.\\ |";

        }

        if (totalGuesses > incorrectGuesses) {
            
            for (int i = incorrectGuesses; i < totalGuesses; i++) {
                
                finalResult += "     |";

            }
        }

        finalResult += "\n|";

        for (int line5 = 0; line5 < incorrectGuesses; line5++) {

            finalResult += "// \\\\|";

        }

        if (totalGuesses > incorrectGuesses) {
            
            for (int i = incorrectGuesses; i < totalGuesses; i++) {
                
                finalResult += "     |";

            }
        }

        finalResult += "\n";

        for (int line5 = 0; line5 < totalGuesses; line5++) {
            
            finalResult += "+-----";

        }

        finalResult += "+\n";

        return finalResult;

    }
}
