public class DrawScoreboard {

    public static String drawScoreboard(int totalGuesses, int incorrectGuesses) {

        String finalResult = "";

        if (totalGuesses == 1) {

            finalResult +=  "+-----+\n"
                    +       "|     |\n"
                    +       "|     |\n"
                    +       "|     |\n"
                    +       "|     |\n"
                    +       "+-----+";

        } else {

            finalResult +=  "+-----+-----+\n"
                    +       "|\\\\ //|     |\n"
                    +       "| \\V/ |     |\n"
                    +       "| /.\\ |     |\n"
                    +       "|// \\\\|     |\n"
                    +       "+-----+-----+";

        }

        return finalResult;

    }
}
