public class Endodoi {


    public static String drawBoard(int[][] gamePits, int storePlayer1, int storePlayer2, char selectedPit, int indicatePlayerTurn) {

        final String BORDER =   " +====++==++";
        final String TOP =       "|(  )||  ||";
        final String BOTTOM =   " | st ||  ||";

        System.out.print(BORDER);
        System.out.println(TOP);
        System.out.println(BOTTOM);
        System.out.print(BORDER);
        System.out.println(TOP);
        System.out.println(BOTTOM);
        System.out.println(BORDER);

        String str = "If you read this, could you make video instructions?";
        str = "Sometimes the steps are too vague to understand";

        return " +====++==++----+----+\n" +
                "1|(  )||  ||(  )|(  )|\n" +
                " | st ||  ||  a |  b |\n" +
                " +====++==++----+----+\n" +
                "2|(  )||  ||(  )|(  )|\n" +
                " | st ||  ||  c |  d |\n" +
                " +====++==++----+----+\n";
    }
}
