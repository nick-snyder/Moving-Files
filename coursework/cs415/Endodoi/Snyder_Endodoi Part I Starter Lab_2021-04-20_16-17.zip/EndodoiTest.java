import org.junit.Test;

import static org.junit.Assert.*;

public class EndodoiTest {



    @Test
    public void drawBoard1(){

        String expected =   " +====++==++----+----+\n" +
                            "1|(  )||  ||(  )|(  )|\n" +
                            " | st ||  ||  a |  b |\n" +
                            " +====++==++----+----+\n" +
                            "2|(  )||  ||(  )|(  )|\n" +
                            " | st ||  ||  c |  d |\n" +
                            " +====++==++----+----+\n";

        int [][] pits = { {0,0},{0,0}};
        String actual = Endodoi.drawBoard(pits, 0, 0, '!', -1);

        assertEquals(expected,actual);
    }

    @Test
    public void drawBoard0(){

        String expected =   " +====++==++\n" +
                            "1|(  )||  ||\n" +
                            " | st ||  ||\n" +
                            " +====++==++\n" +
                            "2|(  )||  ||\n" +
                            " | st ||  ||\n" +
                            " +====++==++\n";

        int [][] pits = { {0,0},{0,0}};
        String actual = Endodoi.drawBoard(pits, 0, 0, '!', -1);

        assertEquals(expected,actual);
    }


}