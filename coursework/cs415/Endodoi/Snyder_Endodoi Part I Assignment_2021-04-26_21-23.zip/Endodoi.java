//import java.util.Arrays;

/**
 * 
 * 
 * @author Nicholas Snyder
 * @version 26 April 2021
 */

public class Endodoi {
    
    /**
     * 
     * 
     * @param pitsPerRow            int
     * @param numSeeds              int
     * @return                      int[][]
     */

    public static int[][] createNewPits(int pitsPerRow, int numSeeds) {
        
        int[][] array = new int[2][pitsPerRow];

        for (int i = 0; i < 2; i++) {
            
            for (int j = 0; j < pitsPerRow; j++) {
                
                array[i][j] = numSeeds;
            }
        }

        return array;
    }

    /**
     * 
     * 
     * @param playerPits            int[][]
     * @return                      char[][]
     */

    public static char[][] playerPitLabels(int[][] playerPits) {
        
        int length = playerPits.length;
        int width = playerPits[0].length;

        char letter = 'a';

        char[][] array = new char[length][width];

        for (int i = 0; i < playerPits.length; i++) {
            
            for (int j = 0; j < playerPits[i].length; j++) {
                

                array[i][j] = letter++;
            }
        }
        
        return array;
    }

    /**
     * 
     * 
     * @param gamePits              int[][]
     * @param storePlayer1          int
     * @param storePlayer2          int
     * @param selectedPit           char
     * @param indicatePlayerTurn    int
     * @return                      String
     */

    public static String drawBoard(int[][] gamePits, int storePlayer1, 
        int storePlayer2, char selectedPit, int indicatePlayerTurn) {

        String str = "";

        final String BORDER =  " +====++==++";

        str += BORDER;

        for (int line1 = 0; line1 < gamePits[1].length; line1++) {
            
            str += "----+";
        }

        if (indicatePlayerTurn == 1) {
            
            str += "\n1|(";

            if (storePlayer1 == 0) {
                
                str += "  ";

            } else if (storePlayer1 > 9) {

                str += storePlayer1;

            } else {
                
                str += " " + storePlayer1;
            }

            str += ")||\\/||";

        } else {

            str += "\n1|(";

            if (storePlayer1 == 0) {
                
                str += "  ";

            } else if (storePlayer1 > 9) {

                str += storePlayer1;

            } else {
                
                str += " " + storePlayer1;
            }

            str += ")||  ||";
        }

        for (int i = 0; i < gamePits[1].length; i++) {
            
            if (gamePits[0][i] == 0) {

                str += "(  )|";

            } else {

                str += "( " + gamePits[0][i] + ")|";
            }
        }

        if (indicatePlayerTurn == 1) {
            
            str += "\n | st ||/\\||";

        } else {

            str += "\n | st ||  ||";
        }


        for (int j = 0; j < gamePits[1].length; j++) {
            
            if (playerPitLabels(gamePits)[0][j] == selectedPit) {
                
                str += "  * |";

            } else {

                if (indicatePlayerTurn == 2) {
                    
                    str += "    |";

                } else {
                
                    str += "  " + playerPitLabels(gamePits)[0][j] + " |";
                }
            }
        }

        str += "\n" + BORDER;

        for (int line1 = 0; line1 < gamePits[1].length; line1++) {
            
            str += "----+";
        }

        if (indicatePlayerTurn == 2) {
            
            str += "\n2|(";

            if (storePlayer2 == 0) {
                
                str += "  ";

            } else if (storePlayer2 > 9) {

                str += storePlayer2;

            } else {
                
                str += " " + storePlayer2;
            }

            str += ")||\\/||";

        } else {

            str += "\n2|(";
            
            if (storePlayer2 == 0) {
                
                str += "  ";

            } else if (storePlayer2 > 9) {

                str += storePlayer2;

            } else {
                
                str += " " + storePlayer2;
            }

            str += ")||  ||";
        }

        for (int i = 0; i < gamePits[1].length; i++) {
            
            if (gamePits[1][i] == 0) {

                str += "(  )|";

            } else {

                str += "( " + gamePits[1][i] + ")|";
            }
        }

        if (indicatePlayerTurn == 2) {
            
            str += "\n | st ||/\\||";

        } else {

            str += "\n | st ||  ||";
        }

        for (int j = 0; j < gamePits[1].length; j++) {
            
            if (playerPitLabels(gamePits)[1][j] == selectedPit) {
                
                str += "  * |";

            } else {

                if (indicatePlayerTurn == 1) {
                    
                    str += "    |";

                } else {
                
                    str += "  " + playerPitLabels(gamePits)[1][j] + " |";
                }
            }
        }

        str += "\n" + BORDER;

        for (int line1 = 0; line1 < gamePits[1].length; line1++) {
            
            str += "----+";
        }

        str += "\n";

        return str;        
    }

    /**
     * 
     * 
     * @param args                  String[]
     */

    public static void main(String[] args) {
        
        createNewPits(2, 0);

        int[][] pits = {{3, 2, 1, 0}, {4, 4, 4, 1}};

        System.out.println(drawBoard(pits, 0, 0, '!', -1));
    }
}
